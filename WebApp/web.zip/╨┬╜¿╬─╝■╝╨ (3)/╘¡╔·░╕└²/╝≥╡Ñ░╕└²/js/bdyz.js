/**
 * Created by LJY on 2016/12/28.
 */

var _yhm = document.getElementById("yhm");
var _mm = document.getElementById("mm");
var _dh = document.getElementById("dh");
var _yx = document.getElementById("yx");
var _wz = document.getElementById("wz");

var _syhm = document.getElementById("spanYhm");
var _smm = document.getElementById("spanMm");
var _sdh = document.getElementById("spanDh");
var _syx = document.getElementById("spanYx");
var _swz = document.getElementById("spanWz");



yz(/^[a-zA-Z]\w{5,11}$/,_yhm,"账号不对噢~请小主输入首字母为大写,6~12位账号",_syhm);
yz(/^\d{5,11}$/,_mm,"密码不对噢~ 请小主输入6~12位数字密码",_smm);
yz(/^[1][358][0-9]{9}$/,_dh,"电话不对噢~ 请小主输入11位电话号码",_sdh);
yz(/^\w+@(163|126|qq)\.(com|cn|con)$/,_yx,"邮箱不对呢~ 小主只能输入126.163.qq邮箱噢~",_syx);
yz(/^(http:\/\/)[a-zA-z]+(\.com)$/,_wz,"网址不对~ 小主要输入正确网址噢~" ,_swz)

function yz(rule1,name,shuchu,spanname){
	name.onkeyup = function(){
		var rule = rule1

		if(rule.test(name.value)){
			spanname.textContent = "账号合法"
			spanname.style.color = "green"
		}else if(name.value == 0){
			spanname.textContent = "账号不能为空噢"
			spanname.style.color = "red"
		}else{
			spanname.textContent = shuchu
			spanname.style.color = "red"
		}
	}
}

//拖动窗口
var _wk = document.getElementById("wk");
var _h1 = document.getElementById(h1)
_wk.onmousedown = function(e){
	e = e || window.event
	//鼠标离父元素的距离
	var _ox = e.offsetX;
	var _oy = e.offsetY;

	document.onmousemove = function(e){
		e = e || window.event;
		//鼠标离浏览器的距离
		var _cx = e.clientX;
		var _cy = e.clientY;
		_wk.style.left = _cx - _ox + "px"
		_wk.style.top = _cy - _oy +"px"
	}
}
_wk.onmouseup = function(){
	document.onmousemove = null
}

