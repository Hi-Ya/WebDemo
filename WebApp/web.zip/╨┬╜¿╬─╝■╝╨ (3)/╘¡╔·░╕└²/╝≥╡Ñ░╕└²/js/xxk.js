//获取全部的li
//获取全部的div
//开始第一个循环，因为不知道_li的长度所以上都是<_li.length
//第二个循环修改li的样式名称
//第三个循环修改div的样式名称、

var _li = document.getElementById("container").getElementsByTagName("li")
var _div = document.getElementById("container").getElementsByTagName("div")

for(var i = 0; i < _li.length; i++){
	_li[i].index = i

	_li[i].onclick = function(){
		for(var n = 0; n < _li.length ; n++){
			_li[n].className = ""
		}
		this.className = "active"

		for(var m = 0; m < _div.length ; m++){
			_div[m].className = ""
		}
		_div[this.index].className = "active"
	}
}





