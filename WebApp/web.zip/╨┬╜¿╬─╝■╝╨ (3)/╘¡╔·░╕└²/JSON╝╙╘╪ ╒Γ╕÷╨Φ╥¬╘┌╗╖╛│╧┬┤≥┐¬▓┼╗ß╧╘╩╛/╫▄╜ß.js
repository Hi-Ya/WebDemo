/*

1. JSON加载商品列表
    JSON模拟数据【明白模式的数据是从哪里来的】
    解析JSON【读取JSON中的每个数据】
    DOM操作【将JSON中解析出来的数据，添加到页面中】

2. 事件委托
    要通过事件委托的方式，给页面上的元素添加事件操作

3. Cookie操作
    读懂保存cookie、修改cookie代码
    熟练读取cookie的操作

4. 购物车页面
    读取所有cookie数据
    拆分cookie数据为数组
    数组中的单个元素，转换成json对象

    JSON解析和DOM操作
 */
