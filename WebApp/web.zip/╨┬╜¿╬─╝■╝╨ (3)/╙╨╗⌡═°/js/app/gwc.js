/**
 * Created by LJY on 2017/1/12.
 */
$(function(){
	$(function(){
		$("#sjwxz").hover(function(){
			$("#sjwx").stop().show()
		},function(){
			$("#sjwx").stop().hide()
		})
	})

	$(function(){
		$("#nav1>li").hover(function(){
			$(this.children[0]).stop().slideDown()
		},function(){
			$(this.children[0]).stop().slideUp()
		})
	})
})

$(function(){
	$("#t1").mouseover(function(){
		$("#tu0").css({"display":"block"})
		$("#tu1").css({"display":"none"})
	})
	$("#t0").mouseover(function(){
		$("#tu0").css({"display":"none"})
		$("#tu1").css({"display":"block"})
	})
})